# flake8: noqa

if __import__("typing").TYPE_CHECKING:
    # import apis into api package
    from elabapi_python_async.api.api_keys_api import ApiKeysApi
    from elabapi_python_async.api.comments_api import CommentsApi
    from elabapi_python_async.api.compounds_api import CompoundsApi
    from elabapi_python_async.api.config_api import ConfigApi
    from elabapi_python_async.api.events_api import EventsApi
    from elabapi_python_async.api.experiments_api import ExperimentsApi
    from elabapi_python_async.api.experiments_categories_api import ExperimentsCategoriesApi
    from elabapi_python_async.api.experiments_status_api import ExperimentsStatusApi
    from elabapi_python_async.api.experiments_templates_api import ExperimentsTemplatesApi
    from elabapi_python_async.api.exports_api import ExportsApi
    from elabapi_python_async.api.extra_fields_keys_api import ExtraFieldsKeysApi
    from elabapi_python_async.api.favorite_tags_api import FavoriteTagsApi
    from elabapi_python_async.api.idps_api import IdpsApi
    from elabapi_python_async.api.import_api import ImportApi
    from elabapi_python_async.api.info_api import InfoApi
    from elabapi_python_async.api.items_api import ItemsApi
    from elabapi_python_async.api.items_types_api import ItemsTypesApi
    from elabapi_python_async.api.links_to_experiments_api import LinksToExperimentsApi
    from elabapi_python_async.api.links_to_items_api import LinksToItemsApi
    from elabapi_python_async.api.notifications_api import NotificationsApi
    from elabapi_python_async.api.reports_api import ReportsApi
    from elabapi_python_async.api.resources_status_api import ResourcesStatusApi
    from elabapi_python_async.api.revisions_api import RevisionsApi
    from elabapi_python_async.api.steps_api import StepsApi
    from elabapi_python_async.api.tags_api import TagsApi
    from elabapi_python_async.api.team_tags_api import TeamTagsApi
    from elabapi_python_async.api.teamgroups_api import TeamgroupsApi
    from elabapi_python_async.api.teams_api import TeamsApi
    from elabapi_python_async.api.todolist_api import TodolistApi
    from elabapi_python_async.api.unfinished_steps_api import UnfinishedStepsApi
    from elabapi_python_async.api.uploads_api import UploadsApi
    from elabapi_python_async.api.user_uploads_api import UserUploadsApi
    from elabapi_python_async.api.users_api import UsersApi
    
else:
    from lazy_imports import LazyModule, as_package, load

    load(
        LazyModule(
            *as_package(__file__),
            """# import apis into api package
from elabapi_python_async.api.api_keys_api import ApiKeysApi
from elabapi_python_async.api.comments_api import CommentsApi
from elabapi_python_async.api.compounds_api import CompoundsApi
from elabapi_python_async.api.config_api import ConfigApi
from elabapi_python_async.api.events_api import EventsApi
from elabapi_python_async.api.experiments_api import ExperimentsApi
from elabapi_python_async.api.experiments_categories_api import ExperimentsCategoriesApi
from elabapi_python_async.api.experiments_status_api import ExperimentsStatusApi
from elabapi_python_async.api.experiments_templates_api import ExperimentsTemplatesApi
from elabapi_python_async.api.exports_api import ExportsApi
from elabapi_python_async.api.extra_fields_keys_api import ExtraFieldsKeysApi
from elabapi_python_async.api.favorite_tags_api import FavoriteTagsApi
from elabapi_python_async.api.idps_api import IdpsApi
from elabapi_python_async.api.import_api import ImportApi
from elabapi_python_async.api.info_api import InfoApi
from elabapi_python_async.api.items_api import ItemsApi
from elabapi_python_async.api.items_types_api import ItemsTypesApi
from elabapi_python_async.api.links_to_experiments_api import LinksToExperimentsApi
from elabapi_python_async.api.links_to_items_api import LinksToItemsApi
from elabapi_python_async.api.notifications_api import NotificationsApi
from elabapi_python_async.api.reports_api import ReportsApi
from elabapi_python_async.api.resources_status_api import ResourcesStatusApi
from elabapi_python_async.api.revisions_api import RevisionsApi
from elabapi_python_async.api.steps_api import StepsApi
from elabapi_python_async.api.tags_api import TagsApi
from elabapi_python_async.api.team_tags_api import TeamTagsApi
from elabapi_python_async.api.teamgroups_api import TeamgroupsApi
from elabapi_python_async.api.teams_api import TeamsApi
from elabapi_python_async.api.todolist_api import TodolistApi
from elabapi_python_async.api.unfinished_steps_api import UnfinishedStepsApi
from elabapi_python_async.api.uploads_api import UploadsApi
from elabapi_python_async.api.user_uploads_api import UserUploadsApi
from elabapi_python_async.api.users_api import UsersApi

""",
            name=__name__,
            doc=__doc__,
        )
    )
